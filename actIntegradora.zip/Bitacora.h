#ifndef Bitacora_h
#define Bitacora_h

class Bitacora{
  private:
    string info, mes, dia, hora;
    long  fechaSegundos;
  public:
    Bitacora();
    Bitacora(string info, string mes, string dia, string hora, long fechaSegundos);
    void setInfo(string);
    void setMes(string);
    void setDia(string);
    void setHora(string);
    void setFechaSegundos(long);
    string getInfo();
    string getMes();
    string getDia();
    string getHora();
    long getFechaSegundos();
};

Bitacora::Bitacora(){
  this->info = "";
  this->mes = "";
  this->dia = "";
  this->hora = "";
  this->fechaSegundos = 0;
}

Bitacora::Bitacora(string log, string month, string day, string hour, long timeInSeconds){
  this->info = log;
  this->mes = month;
  this->dia = day;
  this->hora = hour;
  this->fechaSegundos = timeInSeconds;
}



void Bitacora::setInfo(string x){
  info = x;
}

void Bitacora::setMes(string x){
  mes = x;
}

void Bitacora::setDia(string x){
  dia = x;
}

void Bitacora::setHora(string x){
  hora = x;
}

void Bitacora::setFechaSegundos(long x){
  fechaSegundos = x;
}

string  Bitacora::getInfo(){
  return info;
}

string Bitacora::getMes(){
  return mes;
}

string Bitacora::getDia(){
  return dia;
}

string Bitacora::getHora(){
  return hora;
}

long Bitacora::getFechaSegundos(){
  string soloHoras, soloMinutos, soloSegundos;
  int mesSegundos, diaSegundos, horaSegundos;


  //Convertir hora en segundos
  soloHoras = hora.substr(0,2);
  soloMinutos = hora.substr(3,2);
  soloSegundos = hora.substr(6,2);
  horaSegundos = (stoi(soloHoras) * 3600) + (stoi(soloMinutos) * 60) + stoi(soloSegundos);
  
  //Convertir Dia en segundos
  diaSegundos = stoi(dia) * 86400;

  //Convertir Mes en segundos
  if (mes == "Jan"){ mesSegundos = 1;}
  if (mes == "Feb"){ mesSegundos = 2;}
  if (mes == "Mar"){ mesSegundos = 3;}
  if (mes == "Apr"){ mesSegundos = 4;}
  if (mes == "May"){ mesSegundos = 5;}
  if (mes == "Jun"){ mesSegundos = 6;}
  if (mes == "Jul"){ mesSegundos = 7;}
  if (mes == "Aug"){ mesSegundos = 8;}
  if (mes == "Sep"){ mesSegundos = 9;}
  if (mes == "Oct"){ mesSegundos = 10;}
  if (mes == "Nov"){ mesSegundos = 11;}
  if (mes == "Dic"){ mesSegundos = 12;}
  mesSegundos = mesSegundos * 2629743;

  //sumar todos para obtener la fechaSegundos
  fechaSegundos = mesSegundos + diaSegundos + horaSegundos;

  return fechaSegundos;
}
#endif