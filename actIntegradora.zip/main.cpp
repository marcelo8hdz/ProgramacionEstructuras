#include <iostream>
#include <string>
#include <fstream>
#include <vector>
using namespace std;
#include "Bitacora.h"

void insertionSort(int *arr, int cantidadDeLineas, Bitacora *b1){//ordenar el arreglo
  int j = 0;
  int key = 0;

  for(int i = 1; i< cantidadDeLineas; i++){
    key = arr[i];
    j = i - 1;

    while(j>= 0 && arr[j] > key){
      arr[j + 1] = arr[j];
      j = j - 1;
    }

    arr[j + 1] = key;

  }
}

int binarySearch(int *arr, int *arrBinary, int cantidadBuscada){
  //buscar la posicion de las fechas que ingreso el usuario en el arreglo de fechas
  if(arr[arrBinary[1]] == cantidadBuscada){
    return arrBinary[1];
  }
  if (arrBinary[0] == arrBinary[1] || arrBinary[1] == arrBinary[2]){
    return arrBinary[1];
  }
  else{
    if(arr[arrBinary[1]] > cantidadBuscada){
   
    arrBinary[2] = arrBinary[1];
    arrBinary[1] = (arrBinary[0] + arrBinary[2]) / 2;
    return binarySearch(arr, arrBinary, cantidadBuscada);
    }

    if(arr[arrBinary[1]] < cantidadBuscada){

    arrBinary[0] = arrBinary[1];
    arrBinary[1] = (arrBinary[0] + arrBinary[2]) / 2;
    return binarySearch(arr, arrBinary, cantidadBuscada);
    }

    
  }
}

void crearArchivo(int cantidadDeLineas, int *arr, Bitacora *b1 ){ //crear el archivo ordenado
  ofstream archivoSorted("bitacoraSorted.txt");
  for (int y = 0; y < cantidadDeLineas; y++){
    for (int w = 0; w < cantidadDeLineas; w++){
      if (arr[y] == b1[w].getFechaSegundos()){
        archivoSorted<<b1[w].getInfo()<<'\n';
      }
    }
  }
  archivoSorted.close();
}

void fechaConsulta(int *arr, int cantidadDeLineas, Bitacora *b1){//Preguntar por la informacion de consulta del usuario
  string mesInicial, diaInicial, horaInicial;
  string mesFinal, diaFinal, horaFinal;
  int puntoBajo, puntoAlto;
  Bitacora bconsulta[2]; 

  cout<<"enter the inicial date of your inquiry \n";
  cout<<"month (in 3 letters): ";
  cin>>mesInicial;
  cout<<"day (in two digits, 01): ";
  cin>>diaInicial;
  cout<<"hour (hh:mm:ss): ";
  cin>>horaInicial;

  bconsulta[0].setMes(mesInicial);
  bconsulta[0].setDia(diaInicial);
  bconsulta[0].setHora(horaInicial);
  

  cout<<"enter the final date of your inquiry \n";
  cout<<"month (in 3 letters): ";
  cin>>mesFinal;
  cout<<"day (in two digits, 01): ";
  cin>>diaFinal;
  cout<<"hour (hh:mm:ss): ";
  cin>>horaFinal;

  bconsulta[1].setMes(mesFinal);
  bconsulta[1].setDia(diaFinal);
  bconsulta[1].setHora(horaFinal);
  
  int arrBinary[3] = {0, cantidadDeLineas/2, cantidadDeLineas};

  puntoBajo = binarySearch(arr, arrBinary,  bconsulta[0].getFechaSegundos());
  int arrBinaryAlto[3] = {0, cantidadDeLineas/2, cantidadDeLineas};
  puntoAlto = binarySearch(arr, arrBinaryAlto, bconsulta[1].getFechaSegundos());

  int x = 0;
  for (int y = puntoBajo + 1; y < puntoAlto + 1; y++){
    for (int w = 0; w < cantidadDeLineas; w++){
      if (arr[y] == b1[w].getFechaSegundos()){
        cout<<b1[w].getInfo()<<'\n';
        x++;

      }
    }
  }
  cout<<"there were "<<x<<" searches in that time period";
}

void leerBitacora() {//lee el archivo de la bitacora
  int cantidadDeLineas = 0, i = 0;
  ifstream archivo("bitacora.txt");
  string lineaArchivo;

  if(archivo.is_open()){
    //loop para contar las lineas del documento
    while(getline(archivo, lineaArchivo)){
      cantidadDeLineas++;
    }
    archivo.close();
  }
  //loop para crear los objetos 
  Bitacora b1[cantidadDeLineas];
  archivo.open("bitacora.txt");
  
  if(archivo.is_open()){

    while(getline(archivo, lineaArchivo)){
      b1[i].setInfo(lineaArchivo);
      b1[i].setMes(lineaArchivo.substr(0, 3));
      b1[i].setDia(lineaArchivo.substr(4, 2));
      b1[i].setHora(lineaArchivo.substr(7, 8));
      i++;
    }
    archivo.close();
  }

  //loop para crear un arreglo con las fechas en Segundos
  int arr[cantidadDeLineas];
  for(int y = 0; y < cantidadDeLineas; y++){
    arr[y] = b1[y].getFechaSegundos();
  }
  //ordenar el arreglo de las fechas en segundos
  insertionSort(arr, cantidadDeLineas, b1);
  //crear el archivo ordenado
  crearArchivo(cantidadDeLineas, arr, b1);
  fechaConsulta(arr, cantidadDeLineas, b1);
  
}

int main(){
  leerBitacora();

}